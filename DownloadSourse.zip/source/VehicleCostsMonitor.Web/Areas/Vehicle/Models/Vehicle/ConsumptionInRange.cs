﻿namespace VehicleCostsMonitor.Web.Areas.Vehicle.Models
{
    public class ConsumptionInRange
    {
        public double From { get; set; }

        public double To { get; set; }

        public int Count { get; set; }
    }
}