﻿namespace VehicleCostsMonitor.Web.Infrastructure.Extensions.ExcelExport.Interfaces
{
    using Microsoft.AspNetCore.Mvc;

    public interface IExcelResult : IActionResult
    {
    }
}
