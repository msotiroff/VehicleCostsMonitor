﻿namespace VehicleCostsMonitor.Models
{
    public class GearingType : BaseType
    {
    }
}