﻿namespace VehicleCostsMonitor.Models
{
    public class FuelEntryType : BaseType
    {
    }
}