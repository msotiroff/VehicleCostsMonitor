﻿namespace VehicleCostsMonitor.Web.Areas.Admin.Models.Enums
{
    public enum LogSearchCriteria
    {
        Email,
        Controller,
        Action,
        Http_Method
    }
}
