﻿namespace VehicleCostsMonitor.Web.Areas.Identity.Services.Email
{
    public class SendGridOptions
    {
        public string SendGridApiKey { get; set; }
    }
}
