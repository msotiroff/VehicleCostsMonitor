﻿namespace VehicleCostsMonitor.Web.Areas.Vehicle.Models.Enums
{
    public enum PricingType
    {
        Total,
        Unit
    }
}
