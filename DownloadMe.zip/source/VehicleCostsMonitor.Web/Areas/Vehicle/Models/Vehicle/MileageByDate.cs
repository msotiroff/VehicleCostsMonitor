﻿namespace VehicleCostsMonitor.Web.Areas.Vehicle.Models
{
    using System;

    public class MileageByDate
    {
        public DateTime Date { get; set; }

        public double Consumption { get; set; }
    }
}