﻿namespace VehicleCostsMonitor.Web.Infrastructure.Utilities.Interfaces
{
    using System;

    public interface IDateTimeProvider
    {
        DateTime GetCurrentDateTime();
    }
}
