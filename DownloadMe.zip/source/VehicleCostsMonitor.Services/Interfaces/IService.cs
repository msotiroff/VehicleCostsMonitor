﻿namespace VehicleCostsMonitor.Services.Interfaces
{
    // Marker interface
    public interface IService
    {
    }
}
