﻿namespace VehicleCostsMonitor.Models
{
    public class VehicleType : BaseType
    {
    }
}