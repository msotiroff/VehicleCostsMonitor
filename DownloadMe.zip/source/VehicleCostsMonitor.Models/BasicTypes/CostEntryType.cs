﻿namespace VehicleCostsMonitor.Models
{
    public class CostEntryType : BaseType
    {
    }
}