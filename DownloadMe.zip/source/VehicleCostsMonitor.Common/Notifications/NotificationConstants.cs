﻿namespace VehicleCostsMonitor.Common.Notifications
{
    public class NotificationConstants
    {
        public const string NotificationMessageKey = "NotificationMessage";

        public const string NotificationTypeKey = "NotificationMessageType";
    }
}
