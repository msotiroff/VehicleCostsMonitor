﻿namespace VehicleCostsMonitor.Common.AutoMapping.Interfaces
{
    // Marker interface
    public interface IAutoMapWith<TModel>
    {
    }
}
